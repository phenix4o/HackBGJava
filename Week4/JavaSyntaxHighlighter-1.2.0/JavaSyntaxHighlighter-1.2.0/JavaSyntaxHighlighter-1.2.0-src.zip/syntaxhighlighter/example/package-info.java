/**
 * Usage example.
 */
package syntaxhighlighter.example;