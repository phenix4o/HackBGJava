/**
 * The parser.
 */
package syntaxhighlighter.parser;